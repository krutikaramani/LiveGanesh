<?php session_start (); ?>
<?php include 'top.php';?>

<script type="text/javascript" src="assets/scripts/fileuplod/jquery.min.js"></script>
<script type="text/javascript" src="assets/scripts/fileuplod/file_uploads.js"></script>
<script type="text/javascript" src="assets/scripts/fileuplod/vpb_script.js"></script>

<script type="text/javascript">
function selectCity(country_id){
	if(country_id!="-1"){
		loadData('state',country_id);
		$("#city_dropdown").html("<option value='-1'>Select city</option>");	
	}else{
		$("#state_dropdown").html("<option value='-1'>Select state</option>");
		$("#city_dropdown").html("<option value='-1'>Select city</option>");		
	}
}

function selectState(state_id){
	if(state_id!="-1"){
		loadData('city',state_id);
	}else{
		$("#city_dropdown").html("<option value='-1'>Select city</option>");		
	}
}

function loadData(loadType,loadId){
	var dataString = 'loadType='+ loadType +'&loadId='+ loadId;
	$("#"+loadType+"_loader").show();
    $("#"+loadType+"_loader").fadeIn(400).html('<img src="assets/img/loading.gif" />');
	$.ajax({
		type: "POST",
		url: "loadData.php",
		data: dataString,
		cache: false,
		success: function(result){
 			$("#"+loadType+"_loader").hide();
			$("#"+loadType+"_dropdown").html("<option value='-1'>Select "+loadType+"</option>");  
			$("#"+loadType+"_dropdown").append(result);  
		}
	});
}
</script>
 

    <div class="main">
      <div class="container">
        <ul class="breadcrumb">
            <li><a href="index.html">Home</a></li>
            <li class="active">Account Settings</li>
        </ul>
        <!-- BEGIN SIDEBAR & CONTENT -->
        <div class="row margin-bottom-40">
          <!-- BEGIN CONTENT -->
          <div class="col-md-12 col-sm-12">
          <?php 
 		  if(isset($_POST['save']))
		  {
			  	$full_name =  trim(mysql_real_escape_string($_POST['full_name']));
 			  	$mobile =  trim(mysql_real_escape_string($_POST['mobile']));
			  	$contacts =  trim(mysql_real_escape_string($_POST['contacts']));
			  	$display_name =  trim(mysql_real_escape_string($_POST['display_name']));
			  	$website_url =  trim(mysql_real_escape_string($_POST['website_url']));
			  	$country =  trim(mysql_real_escape_string($_POST['country']));
			  	$state =  trim(mysql_real_escape_string($_POST['state']));
			  	$city =  trim(mysql_real_escape_string($_POST['city']));
			  	$address =  trim(mysql_real_escape_string($_POST['address']));
			  	$area =  trim(mysql_real_escape_string($_POST['area']));
			  	$post_code =  trim(mysql_real_escape_string($_POST['post_code']));
				if(isset($_POST['subscribe']) ) { $subscribe = 1;} else {$subscribe = 0; }
 					
				$query = "update members set full_name = '$full_name', mobile = '$mobile', contacts = '$contacts', display_name  = '$display_name', 				website_url = '$website_url', country_id = '$country', state_id = '$state', city_id = '$city', address = '$address', area = '$area', pincode = '$post_code', newsletter = '$subscribe', profile_updated = 1  where id = '$_SESSION[id]' ";
				mysql_query($query) or die (mysql_query());
				
				?> <div class="note note-success"><p> Your Profile detail updated successfully.</p> </div> <?php 
					 $count = mysql_num_rows(mysql_query("select * from ganesh where owner_id = '$_SESSION[id]' and profile_updated != '1' "));
					if($count == 1)
					{
							echo "<script language='javascript'> window.location = 'ganesh_profile.php?flag=1'; </script>";
 					}
			 
		  }
		  
		  	if(isset($_GET['flag']))
			{
				echo "<div class='note note-success'><p> <strong>Your are login first time. Please update your profile detail.</strong></p> </div>";
			}
		  
		  	$data = mysql_fetch_assoc(mysql_query("select * from members where id = '$_SESSION[id]'"));
		  	$sqlCountry="select * from countries";
			$resCountry=mysql_query($sqlCountry);
			
		  	$state_list="select * from state_list";
			$resState=mysql_query($state_list);
			
		  	$city_list="select * from city_list";
			$resCity=mysql_query($city_list);
 

		  ?>
          
          
            
            <!-- Account Settings ST -->
            <div class="panel-group checkout-page accordion scrollable" id="accoun-settings">

               <!-- Personal Info ST -->
              <div id="personal-info" class="panel panel-default">
                <div class="panel-heading">
                  <h2 class="panel-title">
                    <a     href="#" class="accordion-toggle">
                      Personal Information
                    </a>
                  </h2>
                </div>

                
                <form action="member_profile.php" method="post"  id="vasPLUS_Programming_Blog_Form" enctype="multipart/form-data">
              
               
                <div id="personal-info-content" class="panel-collapse collapse in">
                  <div class="panel-body row">
                    <div class="col-md-6 col-sm-6">
                      <h3>Your Personal Details</h3>
                      <div class="form-group">
                        <label for="fullname">Full Name</label>
                        <div class="input-group">
                          <span class="input-group-addon"><i class="fa fa-user"></i></span>
                          <input type="text" class="form-control" id="full-name" name="full_name" placeholder="Pratik Sejpal" 
                          value="<?php echo $data['full_name']; ?>" >
                        </div>
                      </div>
                       <div class="form-group">
                        <label for="email">Email</label>
                        <div class="input-group">
                          <span class="input-group-addon"><i class="fa fa-envelope-o"></i></span>
                          <input type="text" class="form-control" id="email" name="e_mail" placeholder="pratik@in.com" disabled="disabled"
                          value="<?php echo $data['email']; ?>" >
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="telephone">Mobile <span class="require">*</span></label>
                        <div class="input-group">
                          <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                          <input type="text" class="form-control" id="mobile" name="mobile" placeholder="Mobile Number"
                          value="<?php echo $data['mobile']; ?>" >
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="contacts">Other Contacts</label>
                        <div class="input-group">
                          <span class="input-group-addon"><i class="fa fa-print"></i></span>
                          <input type="text" class="form-control" id="contacts" name="contacts" placeholder="Land Line or  Other mobile no"
                           value="<?php echo $data['contacts']; ?>" >

                        </div>
                      </div>

                      <div class="form-group">
                        <label for="firstname">Display Name</label>
                        <div class="input-group">
                          <span class="input-group-addon"><i class="fa fa-user"></i></span>
                          <input type="text" class="form-control" id="display-name" name="display_name" placeholder="e.g Lal Baug Cha Raja"
                          value="<?php echo $data['display_name']; ?>" >
                        </div>
                      </div>

                      <div class="form-group">
                        <label for="firstname">Website URL</label>
                        <div class="input-group row">
                          <div class="col-md-6">
                            <div class="input-group">
                              <span class="input-group-addon"><i class="fa fa-desktop"></i></span>
                              <input type="text" id="display-name" class="form-control" placeholder="http://www.liveganesh.com/" disabled="disabled">
                            </div>
                          </div>
                          <div class="col-md-6 col-md-pull-1">
                            <input type="text" id="display-name" class="form-control" name="website_url" placeholder="lalbaugcharaja" 
                            value="<?php echo $data['website_url']; ?>" >
                          </div>
                        </div>
                      </div>

                       <h3>Profile Picture</h3>
                      <div class="form-group">
                        <label for="password">Upload Photo </label><br />
                        <div class="row">
                          <div class="col-md-5 col-sm-5">
                            <div class="profile_thumb" id="vasPhoto_uploads_Status"><?php if($data['photo'] == '') { ?> 
                            <img src="assets/img/noimage.jpg" width="160" />
                            <?php } else { ?>
                            <img src="profile_pic/<?php echo $data['photo']; ?>" width="160" />
                             <?php }?>
                            </div>
                          </div>
                          <div class="input-group col-md-7 col-sm-7" style="position: relative; top: 70px; left: -1.1em;">
                            <span class="input-group-addon"><i class="fa fa-camera"></i></span>
                            <input type="file" class="form-control" placeholder="Upload Profile Picture" name="vasPhoto_uploads" id="vasPhoto_uploads" onChange="javascript:void(0);" >
                            
  

                          </div>
                        </div>
                        
                      </div>
                    </div>
                    <div class="col-md-6 col-sm-6">
                      <h3>Your Address</h3>
                      <div class="form-group">
                        <label for="country">Country <span class="require">*</span></label>
                        <div class="input-group">
                          <span class="input-group-addon"><i class="fa fa-globe"></i></span>
                          <select class="form-control input-sm" id="country" name="country" onchange="selectCity(this.options[this.selectedIndex].value)">
                             <option value="-1">Select Country</option>
								<?php
								while($rowCountry=mysql_fetch_array($resCountry)){
									?>
									<option  value="<?php echo $rowCountry['id']?>"
                                    <?php if($data['country_id'] == $rowCountry['id']) { echo "selected"; } ?>
                                    ><?php echo $rowCountry['country_name']?></option>
									<?php
								}
								?>
                          </select>
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="region-state">Region/State <span class="require">*</span></label>
                        <div class="input-group">
                          <span class="input-group-addon"><i class="fa fa-globe"></i></span>
                          <select  class="form-control input-sm" id="state_dropdown" name="state" onchange="selectState(this.options[this.selectedIndex].value)">
                          <?php  if(isset($data['state_id'])) { ?>
                            
                              <option value="-1">Select State</option>
								<?php
								while($rowState=mysql_fetch_array($resState)){
									?>
									<option   value="<?php echo $rowState['id']?>"
                                    <?php if($data['state_id'] == $rowState['id']) { echo "selected"; } ?>
                                    ><?php echo $rowState['state']?></option>
									<?php
								}
								?>

                          <?php  } else {?>
								<option value="-1">Select State</option>
                                <?php } ?>
                          </select>
                        </div>
                        <span id="state_loader"></span>
                      </div>
                      
                      <div class="form-group">
                        <label for="region-state">City <span class="require">*</span></label>
                        <div class="input-group">
                          <span class="input-group-addon"><i class="fa fa-globe"></i></span>
                          <select class="form-control input-sm" id="city_dropdown" name="city">
                          <?php  if(isset($data['city_id'])) { ?>
                            
                              <option value="-1">Select City</option>
								<?php
								while($rowCity=mysql_fetch_array($resCity)){
									?>
									<option   value="<?php echo $rowCity['id']?>"
                                    <?php if($data['city_id'] == $rowCity['id']) { echo "selected"; } ?>
                                    ><?php echo $rowCity['city']?></option>
									<?php
								}
								?>

                          <?php  } else {?>
								<option value="-1">Select State</option>
                                <?php } ?>
                           </select>
                        </div>
                                                                         <span id="city_loader"></span>
                      </div>
                      <div class="form-group">
                        <label for="address">Address <span class="require">*</span></label>
                        <div class="input-group">
                          <span class="input-group-addon"><i class="fa fa-home"></i></span>
                          <input type="text" class="form-control" id="address" name="address" placeholder="Address"
                          value="<?php echo $data['address']; ?>" >
                        </div>

                      </div>
                      <div class="form-group">
                        <label for="address2">Area (Nearby place)<span class="require">*</span></label>
                        <div class="input-group">
                          <span class="input-group-addon"><i class="fa  fa-road"></i></span>
                          <input type="text" class="form-control" id="area" name="area" placeholder="Area or Nearby place"
                          value="<?php echo $data['area']; ?>" >
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="post-code">Post Code <span class="require">*</span></label>
                        <div class="input-group">
                          <span class="input-group-addon"><i class="fa fa-location-arrow"></i></span>
                          <input type="text" class="form-control" id="post-code" name="post_code" placeholder="Post Code Number"
                          value="<?php echo $data['pincode']; ?>" >
                        </div>
                      </div>
                      
                    </div>
                    <hr>
                    
                    <div class="row">
                      <div class="col-md-6">                      
                        <div class="checkbox">
                          <label>
                            <input type="checkbox" <?php if($data['newsletter'] == '1' ){ echo  'checked="checked"'; } ?> name="subscribe"> I wish to subscribe to the newsletter. 
                          </label>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <button class="btn btn-primary  pull-right" type="submit" name="save" data-toggle="collapse" data-parent="#accoun-settings" data-target="#ganesh-details-content" id="button-payment-address">Save Detail</button>
                      </div>
                    </div>
                  </div>
                </div>
				</form>
				
              </div>
              <!-- Personal Info EN -->

 
               </div>
            <!-- END CHECKOUT PAGE -->
          </div>
          <!-- END CONTENT -->
        </div>
        <!-- END SIDEBAR & CONTENT -->
      </div>
    </div>



<?php  include 'bottom.php';?>